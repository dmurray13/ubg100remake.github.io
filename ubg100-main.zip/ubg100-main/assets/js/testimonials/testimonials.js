const testimonialsArr = [
    {
        name: `sir hype`,
        testimonial: `UBG100 is an incredible place to de-stress and have fun. My friends and I absolutely love this site. It's a great site with an even better community.`,
        pfpsrc: `sirhype.png`
    },
    {
        name: `W1nter`,
        testimonial: `UBG100 is a great website to play your favorite games! It is very easy to play any game you want, especially if you join the Discord server. Owner is very active and bugs are fixed very fast!`,
        pfpsrc: `w1nter.gif`
    },
    {
        name: `Ducxify`,
        testimonial: `UBG100 is one of my favorite sites to visit when I'm bored because there's frequent updates so it never runs out of games to play. Whether you like FPS, rhythm, or strategy games, UBG100 has it all.`,
        pfpsrc: `ducxify.png`
    },
    {
        name: `BECKIRAM`,
        testimonial: `UBG100 is one of my favorite websites to use whenever I am bored at school. It has some of the best games like the Pokemon Series and Retro Bowl (personal favorite). Recommend it to anyone that faces the same boredom that I do at school!`,
        pfpsrc: `beckiram.png`
    },
    {
        name: `GS Jowell`,
        testimonial: `UBG100 is an unblocked game website where you and your friends can play and have fun. Me and my friends absolutely love this app and maybe you will too!`,
        pfpsrc: `gsjowell.png`
    },
    {
        name: `Alpha`,
        testimonial: `UBG100 is a great place to add a little more fun to your day. This website provides a vast variety of games and receives constant updates and improvements, so any bugs or issues get fixed immediately. Make sure to try out UBG100 today!`,
        pfpsrc: `alphaomegaepilison.gif`
    },
    {
        name: `Flamesawoken`,
        testimonial: `I use UBG100 everyday when I'm in school because of its diverse games that it offers. The website design is simple but nice and it is very easy to use. I would 10/10 recommend this website to those who are looking for fun.`,
        pfpsrc: `flamesawoken.gif`
    },
    {
        name: `Locklyn`,
        testimonial: `Real talk UBG100 is such a good website, like they listen to their community about what games people want. As someone whos suggested games for this website is super nice as I can play the games I want at school. You should for sure check out Age of War 2 as it is one of my favorite games`,
        pfpsrc: `locklyn.png`
    },
    {
        name: `uwaaa`,
        testimonial: `UBG100 is a great site to come to when you have some extra time to spare, and it has a large variety of games!! :>`,
        pfpsrc: `uwaa.png`
    },
    {
        name: `puffl`,
        testimonial: `UBG is the best game website to play at school! You can play fun games such as Drift Hunters, Cookie Clicker, and even Super Mario 64! Make sure to have fun and not get caught!`,
        pfpsrc: `puffl.jpg`
    },
    {
        name: `Tacocat`,
        testimonial: `This website is the go to when bored in school. I've been using it for a while and personally recommend minesweeper :)`,
        pfpsrc: `tacocat.png`
    },
]