var sliderArr = [
    {
        boxdivclass: `box1`,
        title: `Rooftop Snipers`,
        desc: `Challenge your friends side by side or play the computer. Shoot your opponent off the map to win.`,
        link: `rooftop-snipers`,
        imgsrc: `rooftop.jpg`
    },
    {
        boxdivclass: `box2`,
        title: `Tube Jumpers`,
        desc: `The last one to stay on the tubes wins. Watch out for miscellaneous objects while watching your back from other players.`,
        link: `tube-jumpers`,
        imgsrc: `tj.jpg`
    },
    {
        boxdivclass: `box3`,
        title: `Slope`,
        desc: `Slope is the ultimate running game that will put your skills to the test, an all-time favorite of the internet!`,
        link: `slope`,
        imgsrc: `slope.jpg`
    },
    {
        boxdivclass: `box4`,
        title: `Stack`,
        desc: `Keep stacking up the blocks as high as you can! Just make sure you don't run out of blocks...`,
        link: `stack`,
        imgsrc: `stack.png`
    },
    {
        boxdivclass: `box5`,
        title: `COLORON`,
        desc: `Match the color of the tower to the bouncing ball. Keep it going for as long as you can! It's not as easy as it looks...`,
        link: `color-on`,
        imgsrc: `coloron.png`
    },
];